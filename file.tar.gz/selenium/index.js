console.log("starting tests...");

const webdriver = require('selenium-webdriver');
const { By } = require('selenium-webdriver');
const assert = require('assert');
/*
TODO (mert)
// Input capabilities
const capabilities = {
 'device' : 'iPhone 11',
 'realMobile' : 'true',
 'os_version' : '14.0',
 'browserName' : 'iPhone',
 'name': 'BStack-[NodeJS] Sample Test', // test name
 'build': 'BStack Build Number 1' // CI/CD job or build name
}
*/
async function runTestWithCaps () {
  let driver = new webdriver.Builder().usingServer(`http://localhost:4444/wd/hub`)
                            // TODO (mert) .withCapabilities(capabilities)
                            .build();
  try{
    await driver.get("https://google.com/");
    await driver.wait(webdriver.until.titleMatches(/Google/i), 10000);
    await driver.executeScript(
      'browserstack_executor: {"action": "setSessionStatus", "arguments": {"status":"passed","reason": "Product has been successfully added to the cart!"}}'
    );
  } catch(e) {
    //marking the test as Failed if product has not been added to the cart
    console.log("Error:", e.message)
    await driver.executeScript(
      'browserstack_executor: {"action": "setSessionStatus", "arguments": {"status":"failed","reason": "Some elements failed to load."}}'
    );
  }
  await driver.quit();
}
runTestWithCaps();
